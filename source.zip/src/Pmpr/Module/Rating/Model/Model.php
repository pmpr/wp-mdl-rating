<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f454cf1a0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Rating\Model; use Pmpr\Module\Rating\Container; class Model extends Container { public function aqyikqugcomoqqqi() { Rate::symcgieuakksimmu(); Feedback::symcgieuakksimmu(); } }
