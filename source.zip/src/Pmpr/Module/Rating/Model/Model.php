<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4235aff1b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Rating\Model; use Pmpr\Module\Rating\Container; class Model extends Container { public function aqyikqugcomoqqqi() { Rate::symcgieuakksimmu(); Feedback::symcgieuakksimmu(); } }
