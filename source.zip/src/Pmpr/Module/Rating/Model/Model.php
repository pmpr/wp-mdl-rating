<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668719be85737             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Rating\Model; use Pmpr\Module\Rating\Container; class Model extends Container { public function aqyikqugcomoqqqi() { Rate::symcgieuakksimmu(); Feedback::symcgieuakksimmu(); } }
