<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606992919432             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Rating\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Feedback extends Common { public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::aessmsgaooqooygy)->guiaswksukmgageq(__("\106\145\145\144\142\141\x63\x6b", PR__MDL__RATING))->muuwuqssqkaieqge(__("\x46\145\x65\144\x62\141\x63\x6b\163", PR__MDL__RATING))->aseucqksocwomwos()->wkesqcmiekqoykag()->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::TEXT)->acokiqqgsmoqaeyu()->gswweykyogmsyawy(__("\124\x65\170\164", PR__MDL__RATING))); parent::ewaqwooqoqmcoomi(); } public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->uccuieiyckcoaqsk()->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::iockmgiyoygcswog)->umokgsqqogccoouo())->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::mswoacegomcucaik)->ukqywcsoogkyoaoa()))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::ioksewgkgwwikiwo)->ucwmaimegouwwocg())->mkksewyosgeumwsa($this->sciaycsmsiekqueg(self::TEXT)); } }
