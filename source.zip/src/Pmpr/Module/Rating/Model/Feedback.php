<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400fa252a8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Rating\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Feedback extends Common { public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::aessmsgaooqooygy)->guiaswksukmgageq(__("\106\145\145\x64\142\x61\x63\153", PR__MDL__RATING))->muuwuqssqkaieqge(__("\x46\145\145\144\142\x61\x63\x6b\163", PR__MDL__RATING))->aseucqksocwomwos()->wkesqcmiekqoykag()->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::TEXT)->acokiqqgsmoqaeyu()->gswweykyogmsyawy(__("\x54\145\170\164", PR__MDL__RATING))); parent::ewaqwooqoqmcoomi(); } public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->uccuieiyckcoaqsk()->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::iockmgiyoygcswog)->umokgsqqogccoouo())->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::mswoacegomcucaik)->ukqywcsoogkyoaoa()))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::ioksewgkgwwikiwo)->ucwmaimegouwwocg())->mkksewyosgeumwsa($this->sciaycsmsiekqueg(self::TEXT)); } }
