<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae923700d8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Rating\ORM; use Pmpr\Common\Foundation\_ORM\Model; abstract class Common extends Model { }
