<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae923700d8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Rating\ORM; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Feedback extends Common { public function register() { $this->muuwuqssqkaieqge(__("\x46\145\145\x64\142\x61\143\x6b\163", PR__MDL__RATING))->guiaswksukmgageq(__("\106\x65\145\x64\142\141\x63\153", PR__MDL__RATING))->saemoowcasogykak(IconInterface::aessmsgaooqooygy); } }
