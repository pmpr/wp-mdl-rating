<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec93bbc49             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Rating\ORM; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Feedback extends Common { public function register() { $this->muuwuqssqkaieqge(__("\106\x65\x65\x64\x62\x61\143\153\163", PR__MDL__RATING))->guiaswksukmgageq(__("\x46\x65\145\144\x62\141\x63\153", PR__MDL__RATING))->saemoowcasogykak(IconInterface::aessmsgaooqooygy); } }
