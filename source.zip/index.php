<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56ed39ce7             |
    |_______________________________________|
*/
 use Pmpr\Module\Rating\Rating; Rating::symcgieuakksimmu();
