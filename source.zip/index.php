<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec93bbc49             |
    |_______________________________________|
*/
 use Pmpr\Module\Rating\Rating; Rating::symcgieuakksimmu();
