<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc57592887             |
    |_______________________________________|
*/
 use Pmpr\Module\Rating\Rating; Rating::symcgieuakksimmu();
